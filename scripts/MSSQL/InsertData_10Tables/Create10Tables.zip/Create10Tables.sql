CREATE TABLE table001
(Essential varchar(256), Enterprise varchar(256), CurrentTime varchar(256))
GO

CREATE TABLE table002
(Essential varchar(256), Enterprise varchar(256), CurrentTime varchar(256))
GO

CREATE TABLE table003
(Essential varchar(256), Enterprise varchar(256), CurrentTime varchar(256))
GO

CREATE TABLE table004
(Essential varchar(256), Enterprise varchar(256), CurrentTime varchar(256))
GO

CREATE TABLE table005
(Essential varchar(256), Enterprise varchar(256), CurrentTime varchar(256))
GO

CREATE TABLE table006
(Essential varchar(256), Enterprise varchar(256), CurrentTime varchar(256))
GO

CREATE TABLE table007
(Essential varchar(256), Enterprise varchar(256), CurrentTime varchar(256))
GO

CREATE TABLE table008
(Essential varchar(256), Enterprise varchar(256), CurrentTime varchar(256))
GO

CREATE TABLE table009
(Essential varchar(256), Enterprise varchar(256), CurrentTime varchar(256))
GO

CREATE TABLE table010
(Essential varchar(256), Enterprise varchar(256), CurrentTime varchar(256))
GO